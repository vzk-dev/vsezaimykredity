<?php
require_once (dirname(__DIR__) . '/seotab.class.php');
class SeoTab_mysql extends SeoTab {}