--------------------
tvSuperSelect
--------------------
Author: Pavel Gvozdb <pa6ok.ru>
--------------------

Тип TV: автозаполняемый список из miniShop2, для реализации тегов в MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/gvozdb/tvSuperSelect/issues