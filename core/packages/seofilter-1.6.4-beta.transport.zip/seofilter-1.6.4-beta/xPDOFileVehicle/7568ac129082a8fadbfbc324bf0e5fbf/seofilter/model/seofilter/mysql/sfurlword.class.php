<?php
require_once (dirname(__DIR__) . '/sfurlword.class.php');
class sfUrlWord_mysql extends sfUrlWord {}