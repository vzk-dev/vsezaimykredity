<?php
class sfUrlWord extends xPDOSimpleObject {}