<?php
/**
 * Default English Lexicon Entries for seoTabs
 *
 * @package seotabs
 * @subpackage lexicon
 */

include_once 'setting.inc.php';
include_once 'properties.inc.php';
include_once 'seotab.inc.php';

$_lang['seotabs'] = 'SEOtabs';
$_lang['seotabs_cmenu_seotab'] = 'SEOtabs';
$_lang['seotabs_cmenu_seotab_desc'] = '';