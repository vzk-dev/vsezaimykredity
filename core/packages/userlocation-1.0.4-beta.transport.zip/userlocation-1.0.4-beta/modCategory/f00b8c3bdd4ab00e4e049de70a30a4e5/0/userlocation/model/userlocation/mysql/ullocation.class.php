<?php
require_once (dirname(__DIR__) . '/ullocation.class.php');
class ulLocation_mysql extends ulLocation {}