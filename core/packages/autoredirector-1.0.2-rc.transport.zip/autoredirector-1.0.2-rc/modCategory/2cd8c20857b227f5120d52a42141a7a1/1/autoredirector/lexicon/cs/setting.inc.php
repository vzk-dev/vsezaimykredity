<?php

$_lang['area_autoredirector_main'] = 'Hlavní';

$_lang['setting_autoredirector_some_setting'] = 'Nastavení';
$_lang['setting_autoredirector_some_setting_desc'] = 'Toto je vysvětlivka pro nastavení';
