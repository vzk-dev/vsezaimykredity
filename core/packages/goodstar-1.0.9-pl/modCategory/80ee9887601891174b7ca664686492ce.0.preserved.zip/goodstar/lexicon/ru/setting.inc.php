<?php

$_lang['area_goodstar_main'] = 'Основные';

$_lang['setting_goodstar_theme'] = 'Тема';
$_lang['setting_goodstar_theme_desc'] = 'Можно выставить одну из возможных: 
* bars-1to10 
* bars-square
* bars-pill
* bars-reversed
* bars-horizontal
* fontawesome-stars
* css-stars
* bootstrap-stars
* fontawesome-stars-o';

$_lang['setting_goodstar_selector'] = 'Класс обертки';
$_lang['setting_goodstar_selector_desc'] = 'Можно выставить свой для генерации звездочек';

$_lang['setting_goodstar_jsCustom'] = 'Путь к js файлу';
$_lang['setting_goodstar_jsCustom_desc'] = '';

$_lang['setting_goodstar_jsUrl'] = 'Путь к файлу плагина звездочек';
$_lang['setting_goodstar_jsUrl_desc'] = '';

$_lang['setting_goodstar_hide_scheme'] = 'Скрыть микроразметку для поисковиков?';
$_lang['setting_goodstar_hide_scheme_desc'] = 'Подключает файл стилей для скрытия микроразметки';