<?php
require_once (dirname(__DIR__) . '/goodstaritem.class.php');
class goodStarItem_mysql extends goodStarItem {}