<?php
require_once (dirname(__DIR__) . '/seotemplatesfield.class.php');
class seoTemplatesField_mysql extends seoTemplatesField {}