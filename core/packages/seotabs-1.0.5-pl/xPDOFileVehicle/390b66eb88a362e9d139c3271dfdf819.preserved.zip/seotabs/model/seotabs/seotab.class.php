<?php
class SeoTab extends xPDOSimpleObject {}