<?php
class goodStarVoteCount extends xPDOSimpleObject {}