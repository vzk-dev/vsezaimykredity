<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'sfField',
    1 => 'sfRule',
    2 => 'sfFieldIds',
    3 => 'sfDictionary',
    4 => 'sfUrls',
    5 => 'sfUrlWord',
  ),
);