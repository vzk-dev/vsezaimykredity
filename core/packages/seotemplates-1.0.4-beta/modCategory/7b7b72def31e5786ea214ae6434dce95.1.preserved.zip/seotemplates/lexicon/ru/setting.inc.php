<?php

$_lang['area_seotemplates_main'] = 'Основные';

$_lang['setting_seotemplates_placeholder_prefix'] = 'Префикс';
$_lang['setting_seotemplates_placeholder_prefix_desc'] = 'Префикс для плейсхолдера полей, например [[+st_pagetitle]]';