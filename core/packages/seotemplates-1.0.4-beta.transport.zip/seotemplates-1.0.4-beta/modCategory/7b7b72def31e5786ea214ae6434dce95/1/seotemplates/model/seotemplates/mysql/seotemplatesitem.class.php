<?php
require_once (dirname(__DIR__) . '/seotemplatesitem.class.php');
class seoTemplatesItem_mysql extends seoTemplatesItem {}