<?php
/**
 * pdoPage French Lexicon Entries for pdoArchive
 *
 * @package pdotools
 * @subpackage lexicon
 * @language fr
 */
$_lang['pdoarchive_month_01'] = 'Janvier';
$_lang['pdoarchive_month_02'] = 'Février';
$_lang['pdoarchive_month_03'] = 'Mars';
$_lang['pdoarchive_month_04'] = 'Avril';
$_lang['pdoarchive_month_05'] = 'Mai';
$_lang['pdoarchive_month_06'] = 'Juin';
$_lang['pdoarchive_month_07'] = 'Juillet';
$_lang['pdoarchive_month_08'] = 'Août';
$_lang['pdoarchive_month_09'] = 'Septembre';
$_lang['pdoarchive_month_10'] = 'Octobre';
$_lang['pdoarchive_month_11'] = 'Novembre';
$_lang['pdoarchive_month_12'] = 'Décembre';
