<?php

$_lang['area_userlocation_main'] = 'Основные';

$_lang['setting_userlocation_dashboard_class'] = 'Css класс виджета';
$_lang['setting_userlocation_dashboard_class_desc'] = 'Css Класс виджета пакета. По умолчанию "dashboard-block-userlocation-half" - половинчатый размер,
 "dashboard-block-userlocation" - целый размер';

$_lang['setting_userlocation_front_css'] = 'Файл с css';
$_lang['setting_userlocation_front_css'] = 'Файл с css для подключения на фронтенде. ';

$_lang['setting_userlocation_front_js'] = 'Файл с javascript';
$_lang['setting_userlocation_front_js_desc'] = 'Файл с javascript для подключения на фронтенде. ';

$_lang['setting_userlocation_default_location'] = 'Локация по умолчанию';
$_lang['setting_userlocation_default_location_desc'] = 'Идентификатор локации пользователя по умолчанию. ';

$_lang['setting_userlocation_detect_location'] = 'Определять локацию';
$_lang['setting_userlocation_detect_location_desc'] = 'Определять локацию пользователя по ip. ';

$_lang['setting_userlocation_ulMethodDetectLocation'] = 'Класс определения локации';
$_lang['setting_userlocation_ulMethodDetectLocation_desc'] = 'Класс определения локации пользователя. По умолчанию "ulDetectLocationByIpGeoBase". 
Доступны "ulDetectLocationBySypexGeo", "ulDetectLocationByDaData"';

$_lang['setting_userlocation_grid_location_fields'] = 'Поля таблицы локаций';
$_lang['setting_userlocation_grid_location_fields_desc'] = 'Поля таблицы локаций через запятую.';

$_lang['setting_userlocation_window_location_fields'] = 'Поля окна локации';
$_lang['setting_userlocation_window_location_fields_desc'] = 'Список полей окна локации через запятую.';

$_lang['setting_userlocation_dadata_api_token'] = 'Token ДаДата Api';
$_lang['setting_userlocation_dadata_api_token_desc'] = 'Token для отправки запроса к ДаДата Api.';