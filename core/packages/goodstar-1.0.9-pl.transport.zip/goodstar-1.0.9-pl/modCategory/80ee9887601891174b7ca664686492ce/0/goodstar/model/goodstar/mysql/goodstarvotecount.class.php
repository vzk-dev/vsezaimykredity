<?php
require_once (dirname(__DIR__) . '/goodstarvotecount.class.php');
class goodStarVoteCount_mysql extends goodStarVoteCount {}