-------------------------------------------------------
Extension: seoTabs for MODX Revolution 2.7.2-pl
-------------------------------------------------------
Version: 1.0.0-beta
Released: January 19, 2020
Since: January 19, 2020
Author: 

Description
    seoTabs