<?php
class tvssOption extends xPDOObject {}