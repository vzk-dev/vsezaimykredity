<?php


$_lang['userlocation_prop_frontCss'] = 'Файл с css стилями для подключения на фронтенде';
$_lang['userlocation_prop_frontJs'] = 'Файл с javascript для подключения на фронтенде';
$_lang['userlocation_prop_actionUrl'] = 'Коннектор для обработки ajax запросов';
$_lang['userlocation_prop_tpl'] = 'Чанк оформления';
$_lang['userlocation_prop_type'] = 'Тип объекта';
$_lang['userlocation_prop_sortby'] = 'Сортировка выборки. Например: "&sortby=`{"createdon":"ASC"}`"';
$_lang['userlocation_prop_sortdir'] = 'Направление сортировки';
$_lang['userlocation_prop_limit'] = 'Лимит выборки';
$_lang['userlocation_prop_toPlaceholder'] = 'Если не пусто, сниппет сохранит все данные в плейсхолдер с этим именем, вместо вывода не экран';