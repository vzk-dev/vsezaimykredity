<?php
/**
 * SeoTab Russian Lexicon Entries for seoTabs
 *
 * @package seotabs
 * @subpackage lexicon
 */
$_lang['seotabs_page_title_tree_tabs'] = 'File tree with tabs';
$_lang['seotabs_page_header_tree_tabs'] = 'SEOtabs';
$_lang['seotabs_tabs_tree_intro_msg'] = 'File tree with tabs';
$_lang['seotabs_tabs_tab_tree_tabs'] = 'File tree';
$_lang['seotabs_tabs_tree_node_qtip'] = 'Tabs: [[+count_enabled_tabs]]/[[+total_tabs]]; Resource type: [[+class_key]]';