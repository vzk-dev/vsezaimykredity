--------------------
Extra: CKEditor
--------------------
Version: 1.2.0
Created: December 7th, 2014
Since: December 5th, 2012
Author: Danil Kostin <danya.postfactum@gmail.com>
License: GNU GPLv2 (or later at your option)

Integrates CKEditor WYSYWYG Editor into MODx Revolution.