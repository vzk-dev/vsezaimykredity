<?php
/**
 * English permissions Lexicon Entries for userlocation
 *
 * @package    userlocation
 * @subpackage lexicon
 */
$_lang['userlocation_save'] = 'Разрешает создание/изменение данных.';