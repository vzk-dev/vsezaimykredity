<?php

/**
 *
 * @property int $id
 * @property int $collection
 * @property int $template
 *
 * @property CollectionContainer $Collection
 * @property CollectionTemplate $Template
 *
 * @package collections
 */
class CollectionSetting extends xPDOSimpleObject
{
}
