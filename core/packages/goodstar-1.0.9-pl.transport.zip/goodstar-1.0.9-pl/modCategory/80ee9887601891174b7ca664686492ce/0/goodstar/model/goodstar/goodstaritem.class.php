<?php

/**
 * @package goodstar
 */
class goodStarItem extends xPDOSimpleObject
{
}