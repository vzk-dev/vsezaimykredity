<?php

$_lang['tvsuperselect_prop_id'] = 'ID ресурса, чьи теги выводим.';
$_lang['tvsuperselect_prop_pageId'] = 'ID ресурса, куда будут ссылаться теги. Для вывода всех документов с этим тегом.';

$_lang['tvsuperselect_prop_tag'] = 'Тег или список тегов разделённых между собой "||".';
$_lang['tvsuperselect_prop_tags'] = 'Алиас параметра "tag".';

$_lang['tvsuperselect_prop_tv'] = 'ID дополнительного поля, по которому производим поиск. Для сниппета tvssResources можно указать несколько ID, через запятую.';
$_lang['tvsuperselect_prop_tvs'] = 'Алиас параметра "tv".';

$_lang['mskuponator_prop_tpl'] = 'Чанк вывода.';
$_lang['mskuponator_prop_tplWrapper'] = 'Обёртка для чанка вывода.';

$_lang['tvsuperselect_prop_outputSeparator'] = 'Разделитель вывода.';
$_lang['tvsuperselect_prop_toPlaceholder'] = 'Сохранить результат в плейсхолдер, вместо прямого вывода на странице.';
$_lang['tvsuperselect_prop_scheme'] = 'Схема формирования url, передаётся в modX::makeUrl(). По-умолчанию -1.';
