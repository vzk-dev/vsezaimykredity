<?php
require_once (dirname(__DIR__) . '/tvssoption.class.php');
class tvssOption_mysql extends tvssOption {}