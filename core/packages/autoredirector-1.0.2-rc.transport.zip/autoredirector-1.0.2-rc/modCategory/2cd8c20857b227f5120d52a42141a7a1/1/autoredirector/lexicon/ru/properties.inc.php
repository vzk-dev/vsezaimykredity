<?php

$_lang['autoredirector_prop_limit'] = 'Ограничение вывода правил на странице.';
$_lang['autoredirector_prop_outputSeparator'] = 'Разделитель вывода строк.';
$_lang['autoredirector_prop_sortBy'] = 'Поле сортировки.';
$_lang['autoredirector_prop_sortDir'] = 'Направление сортировки.';
$_lang['autoredirector_prop_tpl'] = 'Чанк оформления каждого ряда правил.';
$_lang['autoredirector_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице.';
