<?php
require_once (dirname(__DIR__) . '/sfrule.class.php');
class sfRule_mysql extends sfRule {}