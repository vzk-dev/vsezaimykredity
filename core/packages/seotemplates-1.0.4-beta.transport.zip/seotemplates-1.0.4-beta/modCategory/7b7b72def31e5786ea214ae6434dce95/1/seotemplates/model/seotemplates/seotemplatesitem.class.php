<?php

/**
 * @package seotemplates
 */
class seoTemplatesItem extends xPDOSimpleObject
{
}