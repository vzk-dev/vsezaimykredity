--------------------
UserLocation
--------------------
Author: Vgrish <vgrish@gmail.com>
--------------------